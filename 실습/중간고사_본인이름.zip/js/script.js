// 1) 데이터 선언: 연도별 라벨과 각 연도에 따른 취업률 - index.html의 표 참조.


// 차트 옵션 설정
var barOptions = {
    axisY: { // Y축 옵션 설정
        offset: 60, // Y축 라벨과 차트 사이의 거리 설정
        scaleMinSpace: 50, // Y축 간격 설정
        labelInterpolationFnc: function(value) { // Y축 라벨 표시 형식 설정
          return value + ' %' // 각 라벨에 '%' 추가하여 표시
        }
    },
    width: '100%', // 차트 너비 설정
    height: '400px' // 차트 높이 설정
};

// 2) 막대 차트 생성 및 설정 적용
